package com.example.chatserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
