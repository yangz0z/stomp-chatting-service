package com.example.chatserver.member.domain;

public enum Role {
    ADMIN, USER
}
